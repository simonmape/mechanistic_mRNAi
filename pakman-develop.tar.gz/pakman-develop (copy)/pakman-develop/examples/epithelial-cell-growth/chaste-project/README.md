# A template user project for use with Chaste.

**Note - you probably *don't* want to fork this on Github!**
If you do it will stay linked to this repository, and then you won't be allowed to fork any more similar projects!

Instead, select `Import repository` from the `+` menu at the top right of this page whilst logged in to your GitHub account.

Paste:

    https://github.com/Chaste/template_project.git

as the location, give it a personalised name, and click `Begin import`.  This operation should only take a few seconds.

Then see the [User Projects](https://chaste.cs.ox.ac.uk/trac/wiki/ChasteGuides/UserProjects) guide page on the Chaste wiki for more information.
