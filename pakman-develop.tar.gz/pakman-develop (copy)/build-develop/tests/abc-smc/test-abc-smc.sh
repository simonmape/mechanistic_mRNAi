#!/bin/bash
set -euo pipefail

# Process arguments
if [ $# -ne 3 ]
then
    echo "Usage: $0 OFFSET EPSILONS POP_SIZE" 1>&2
    exit 1
fi

offset="$1"
epsilons="$2"
pop_size="$3"

# Create temporary files
temp_number_file=$(mktemp)
temp_input_file=$(mktemp)

# Ensure temporary files are cleaned up if error occurs
trap "rm -f $temp_number_file $temp_input_file" ERR

# Store 0 in temporary number file
echo 0 > $temp_number_file

# Run pakman
"/home/user/build-develop/src/pakman" serial smc $temp_input_file \
    --parameter-names=p \
    --population-size=$pop_size \
    --epsilons=$epsilons \
    --simulator="'/home/user/build-develop/tests/abc-smc/../abc-rejection/return-zero-else-one-if-parameter-plus-offset-is-even.sh' $offset" \
    --prior-sampler="'/home/user/build-develop/tests/abc-smc/../abc-rejection/increment-and-print-number.sh' $temp_number_file" \
    --perturber="'/home/user/build-develop/tests/abc-smc/perturber.sh' $offset" \
    --prior-pdf="'/home/user/build-develop/tests/abc-smc/prior-pdf.sh'" \
    --perturbation-pdf="'/home/user/build-develop/tests/abc-smc/perturbation-pdf.sh' $offset"


# Clean up temporary files
rm -f $temp_number_file $temp_input_file
