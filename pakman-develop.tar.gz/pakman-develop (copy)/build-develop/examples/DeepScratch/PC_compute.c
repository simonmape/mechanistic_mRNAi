/**
 * original simulation code author: Alexander P. Browning (ap.browning@qut.edu.au)
 * code adapted for use with Pakman ABC simulator by Simon Martina-Perez
 * martinaperez@maths.ox.ac.uk
 * Date: January 2021
 */

#include <math.h>
#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <string.h>

#define JC_VORONOI_IMPLEMENTATION
#include "jc_voronoi.h"

// Universal constants
#define pi          3.14159265358979323846
#define min(a,b)    (((a) < (b)) ? (a) : (b))
#define max(a,b)    (((a) < (b)) ? (b) : (a))


/* SETTINGS */

// Max agents
const int Nmax = 5000;

// Density profile settings
const int nBins = 64;
double BinWidth = 8;

// Pair correlation settings
double PC_dr        = 1.75;
const int PC_nBins  = 20;

//Set seed
//const int seed = 42;
/* END SETTINGS */

/**
 * RANDOM NUMBER GENERATOR
 */
int rand2(void);
int rseed = 0;
//inline void srand2(int x) {
//    rseed = x;
//}
#define RAND_MAX2 ((1U << 31) - 1)
inline int rand2() {
    return rseed = (rseed * 1103515245 + 12345) & RAND_MAX2;
}



/**
 * UNIFORM NUMBER GENERATOR
 */
double sampleU() {
    double random = ((double)rand2()) / ((double)RAND_MAX2);
    return random;
}


/**
 * VM SAMPLE
 */
double VM(double x, double mu, double kappa) {

    double out = exp(kappa * cos(x - mu));
    return out;

}
double sampleVM(double mu, double kappa) {

    // Sample from non-normalised density with rejection sampling
    double fmax = VM(mu,mu,kappa);

    double x = sampleU()*2*pi - pi;
    double y = VM(x,mu,kappa);
    double u = sampleU()*fmax;

    while (u > y) {
        x = sampleU()*2*pi - pi;
        y = VM(x,mu,kappa);
        u = sampleU()*fmax;
    }

    return x;

}


/**
 * PERIODIC SQUARE DISTANCE BETWEEN AGENTS
 */
double distance2(double x1, double x2, double y1, double y2, double L, double H) {

    double dx = fabs(x1 - x2);
    double dy = fabs(y1 - y2);

    dx = min(dx,L - dx);
    dy = min(dy,H - dy);

    double d = pow(dx,2) + pow(dy,2);
    return d;

}


/**
 * 1D PERIODIC DISPLACEMENT (x1 -> x2)
 */
double disp(double x1, double x2, double L) {

    double s = 0;

    double dx = x2 - x1;
    double adx = fabs(dx);
    double dxL = L - adx;

    if (adx < dxL) {
        s = dx;
    } else {
        if (x1 < L / 2) {
            s = -dxL;
        } else {
            s = dxL;
        }
    }

    return s;

}


/**
 * GAUSSIAN KERNEL
 */
double kernel(double r2, double sigma2, double gamma) {

    double y = 0;

    if (r2 < 9 * sigma2) {

        y = gamma * exp( -r2 / (2 * sigma2) );

    }

    return y;

}


/*
 * RANDOMLY CHOOSE
 */
int choose_agent(double* M, double M_tot) {

    int i = 0;
    double Mc = max(0,M[i]);
    double alpha = sampleU() * M_tot;
    while (alpha > Mc) {
        i += 1;
        Mc += max(0,M[i]);
    }
    return i;

}


/*
 * PERIODIC MODULUS
 */
double mod(double x, double L) {

    if (x <= 0) {
        x += L;
    } else if (x >= L) {
        x -= L;
    }

    return x;

}


/*
 * CALCULATE PAIR CORRELATION
 *  AVERAGE OF PERODIC PC BETWEEN Y < 400 AND Y > 1500
 */
int PairCorrelation(int N, double * X, double * Y, double L, double * PC) {
    
    // Initialise
    double PC1[PC_nBins];
    double PC2[PC_nBins];
    for (int i = 0; i < PC_nBins; i++) {
        PC1[i] = 0;
        PC2[i] = 0;
    }
    
    double x0, y0, x1, y1, dx, dy, dist;

    int N1 = 0;      // N < 108
    int N2 = 0;      // N > 404
    
    
    // Loop through agents 1 (x0,y0)
    for (int i = 0; i < N; i++) {
        x0 = X[i];
        y0 = Y[i];
        
        // y0 < 108 (and only look at second agent with y1 < 108)
        if (y0 < 108) {
            N1 += 1;
            
            // Loop through agents 2 (x1,y1)
            for (int j = 0; j < N; j++) { if (i != j) {
                x1 = X[j];
                y1 = Y[j];
                
                if (y1 < 108) {
                    
                    dx = fabs(x1 - x0);
                    dx = min(dx,L - dx);
                    
                    dy = fabs(y1 - y0);
                    dy = min(dy,108 - dy);
                    
                    dist = sqrt(dx * dx + dy * dy);
                    
                    // Bin distance
                    for (int k = 0; k < PC_nBins; k++) {
                        if (dist >= k * PC_dr && dist < (k+1) * PC_dr) {
                            PC1[k] += 1;
                            break;
                        }
                    }
                    
                } // end (y1 < 108)
                
            }} // end agent loop 2
                        
        } // end agent loop 1 (y0 < 108)
        
               
        // y0 > 404 (and only look at second agent with y1 > 404)
        if (y0 > 404) {
            N2 += 1;
            
            // Loop through agents 2 (x1,y1)
            for (int j = 0; j < N; j++) { if (i != j) {
                double x1 = X[j];
                double y1 = Y[j];
                
                if (y1 > 404) {
                    
                    dx = fabs(x1 - x0);
                    dx = min(dx,L - dx);
                    
                    dy = fabs(y1 - y0);
                    dy = min(dy,108 - dy);
                    
                    dist = sqrt(dx * dx + dy * dy);
                    
                    // Bin distance
                    for (int k = 0; k < PC_nBins; k++) {
                        if (dist >= k * PC_dr && dist < (k+1) * PC_dr) {
                            PC2[k] += 1;
                            break;
                        }
                    }
                    
                } // end (y1 > 404)
                
            }} // end agent loop 2
                        
        } // end agent loop 1 (y0 > 404)
           
    }
    
    
    // Average and scale to get PC
    for (int i = 0; i < PC_nBins; i++) {

        PC1[i] /= N1 * N1 / (L * 108) * pi * (pow((i+1) * PC_dr,2) - pow(i * PC_dr,2));
        PC2[i] /= N2 * N2 / (L * 108) * pi * (pow((i+1) * PC_dr,2) - pow(i * PC_dr,2));
        
        PC[i] = 0.5 * (PC1[i] + PC2[i]);
        
    }
    
    
    return 1;
    
}


/*
 * CALCULATE DENSITY PROFILE
 */
int DensityProfile(int N, double * Y, double * D) {
    double BinStart;
    double yloc;
    
    // Start D
    for (int i = 0; i < nBins; i++) {
        D[i] = 0;
    }
    
    // Loop through agents
    for (int agent = 0; agent < N; agent++) {
        yloc = Y[agent];
        
        // Determine appropriate bin
        for (int i = 0; i < nBins; i++) {
            BinStart = i * BinWidth;
            if (yloc > BinStart && yloc <= (BinStart + BinWidth)) {
                D[i] += 1;
            }
        }
               
    }
    
    return 1;
    
}

  
/* Link list node */
struct Node { 
    int data; 
    struct Node* next; 
}; 
  
/* Given a reference (pointer to pointer) to the head 
  of a list and an int, push a new node on the front 
  of the list. */
void push(struct Node** head_ref, int new_data) 
{ 
    /* allocate node */
    struct Node* new_node = (struct Node*)malloc(sizeof(struct Node)); 
  
    /* put in the data  */
    new_node->data = new_data; 
  
    /* link the old list off the new node */
    new_node->next = (*head_ref); 
  
    /* move the head to point to the new node */
    (*head_ref) = new_node; 
} 
  
/* Counts the no. of occurrences of a node 
   (search_for) in a linked list (head)*/
int count(struct Node* head, int search_for) 
{ 
    struct Node* current = head; 
    int count = 0; 
    while (current != NULL) { 
        if (current->data == search_for) 
            count++; 
        current = current->next; 
    } 
    return count; 
} 
  
int DegreeDistribution(int N, double * X, double * Y, double * Deg){ 
    struct Node* head = NULL;
    jcv_rect bounding_box = { { 470.0f, 0.0f }, { 650.0f, 512.0f } };
    jcv_diagram diagram;
    jcv_point points[N];
    const jcv_site* sites;
    jcv_graphedge* graph_edge;

    memset(&diagram, 0, sizeof(jcv_diagram));
    srand(0);
    for (int i=0; i<N; i++) {
        points[i].x = (float)X[i];
        points[i].y = (float)Y[i];
      }

    jcv_diagram_generate(N, (const jcv_point *)points, &bounding_box, 0, &diagram);

    sites = jcv_diagram_get_sites(&diagram);
    
    for (int i=0; i<diagram.numsites; i++) {
        int neighborCount =0;
        graph_edge = sites[i].edges;
        while (graph_edge) {
            neighborCount++;
            graph_edge = graph_edge->next;
        }
        push(&head,neighborCount);
      }
    
    for(int i=0; i<10;i++)
    {
        Deg[i] = (double)count(head,i)/diagram.numsites;
    }
    return 1;
}
    


int main(int argc, char *argv[])
{
    char FileNames[1160][50];
    
    //Reads the txt file with the experiment identifiers
    FILE *FileNamesDoc = fopen(argv[1],"r");
    int k =0;
    while (fscanf(FileNamesDoc, "%s", FileNames[k]) != EOF)
    {
        ++k;
    }
    fclose(FileNamesDoc);
    
    
    /*Loop over the experiment identifiers and do the computations in each 
    data file */
    
    for(int i=0; i<k;i++)
    {
        //read in initial conditions from the datafile
        double X[Nmax];
        double Y[Nmax];
        double nums[10000] = {0};
        
        FILE* datafile = fopen(FileNames[i],"r");
        
        int j =0;
        while(fscanf(datafile,"%lf",&nums[j]) != EOF)
        {
            ++j;
        }
        fclose(datafile);
        
        //Initialize values of X and Y locations
        for(int l =0;l<j/2;l++)
        {
            X[l] = nums[l];
            Y[l] = nums[l+j/2];
        }
        
        //Compute the density profile
        double Density[nBins];
        DensityProfile(j/2, Y, Density);
        
        //Compute the pair correlations
        double PC[PC_nBins];
        int Length = 180; //Hardcoded the length in pixels here.
        PairCorrelation(j/2, X, Y, Length, PC);
        
        //Compute the degree distribution
        double Degrees[10];
        DegreeDistribution(j/2, X, Y,Degrees);
        
        
        char *addfilename = malloc(strlen(FileNames[i])+5);
        strcpy(addfilename,"ADD_");
        strcat(addfilename,FileNames[i]);
        
        printf("%s\n",addfilename);
        
        FILE * addfile;
        addfile = fopen (addfilename,"w");
 
        /* write density*/
        for(int i = 0; i < nBins;i++)
        {
            fprintf(addfile, "%lf\n",Density[i]);
        }
        
        /* write pair correlation*/
        for(int i = 0; i < PC_nBins;i++)
        {
            fprintf(addfile, "%lf\n",PC[i]);
        }
        
        /* write degree distribution*/
        for(int i = 0; i < 10;i++)
        {
            fprintf(addfile, "%lf\n",Degrees[i]);
        }
        
        fclose (addfile);
        
    }
         
    return 0;
}
