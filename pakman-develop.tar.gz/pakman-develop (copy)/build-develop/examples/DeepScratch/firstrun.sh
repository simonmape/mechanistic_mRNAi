# Run ABC SMC on Mock
echo "Running ABC SMC on Mock"
/usr/bin/mpiexec -n 3 \
     --oversubscribe \
	../../src/pakman serial adaptive_smc \
    --population-size=75 \
    --acceptance-size=25\
    --epsilons=1,1,1 \
    --parameter-names=m,p,gm,gp,gb,seed \
    --simulator="./simulator 4.04 2 180 512 2 Mock.txt" \
    --prior-sampler="python prior-sampler.py 0 10 0.02 0.05 -2 2 0 0.02 0 35" \
    --perturber="python perturber.py 0.5 0.005 0.1 0.005 0.5" \
    --prior-pdf="python prior-pdf.py 0 10 0.02 0.05 -2 2 0 0.02 0 35" \
    --perturbation-pdf="python perturbation-pdf.py 0.5 0.005 0.1 0.005 0.5" \
    > Mock_params.out 2>&1

echo "Results saved in Mock_params.out"

# Run ABC SMC on CDC42
echo "Running ABC SMC on CDC42"
/usr/bin/mpiexec -n 3 \
     --oversubscribe \
	../../src/pakman serial adaptive_smc \
    --population-size=75 \
    --acceptance-size=25\
    --epsilons=1,1,1 \
    --parameter-names=m,p,gm,gp,gb,seed \
    --simulator="./simulator 4.04 2 180 512 2 CDC42.txt" \
    --prior-sampler="python prior-sampler.py 0 10 0.02 0.05 -2 2 0 0.02 0 35" \
    --perturber="python perturber.py 0.5 0.005 0.1 0.005 0.5" \
    --prior-pdf="python prior-pdf.py 0 10 0.02 0.05 -2 2 0 0.02 0 35" \
    --perturbation-pdf="python perturbation-pdf.py 0.5 0.005 0.1 0.005 0.5" \
    > CDC42_params.out 2>&1

echo "Results saved in Mock_params.out"

# Run ABC SMC on CDH5
echo "Running ABC SMC on CDH5"
/usr/bin/mpiexec -n 3 \
     --oversubscribe \
	../../src/pakman serial adaptive_smc \
    --population-size=75 \
    --acceptance-size=25\
    --epsilons=1,1,1 \
    --parameter-names=m,p,gm,gp,gb,seed \
    --simulator="./simulator 4.04 2 180 512 2 CDH5.txt" \
    --prior-sampler="python prior-sampler.py 0 10 0.02 0.05 -2 2 0 0.02 0 35" \
    --perturber="python perturber.py 0.5 0.005 0.1 0.005 0.5" \
    --prior-pdf="python prior-pdf.py 0 10 0.02 0.05 -2 2 0 0.02 0 35" \
    --perturbation-pdf="python perturbation-pdf.py 0.5 0.005 0.1 0.005 0.5" \
    > CDH5_params.out 2>&1
    
echo "Results saved in Mock_params.out"
